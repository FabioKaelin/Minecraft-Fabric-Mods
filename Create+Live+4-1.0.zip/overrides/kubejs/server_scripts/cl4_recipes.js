//Create Live 4 Custom Recipes
//Author: RGB Pixl

ServerEvents.recipes(event => {


//Remove
event.remove({output: 'createaddition:electric_motor'})
event.remove({output: 'createaddition:alternator'})
event.remove({output: 'farmersdelight:hamburger'})


//Gearcoins Bottom Up    
    event.shapeless('1x kubejs:golden_gearcoin', ['4x kubejs:copper_gearcoin'])
    event.shapeless('1x kubejs:diamond_gearcoin', ['4x kubejs:golden_gearcoin'])
    event.shapeless('1x kubejs:netherite_gearcoin', ['4x kubejs:diamond_gearcoin'])
  
    event.shaped('1x kubejs:netherite_gearcoin_prestige', [
      ' A ',
      'ABA',
      ' A '
    ], {
      A: 'kubejs:netherite_gearcoin',
      B: 'minecraft:nether_star'
    })


//Gearcoins Top Down
    event.shapeless('4x kubejs:diamond_gearcoin', ['kubejs:netherite_gearcoin_prestige'])
    event.shapeless('4x kubejs:diamond_gearcoin', ['kubejs:netherite_gearcoin'])
    event.shapeless('4x kubejs:golden_gearcoin', ['kubejs:diamond_gearcoin'])
    event.shapeless('4x kubejs:copper_gearcoin', ['kubejs:golden_gearcoin'])


// Create Mech Crafting
    event.recipes.createMechanicalCrafting('minecraft:elytra', [
        '  A  ',
        ' CBC ',
        'GFDFG',
        'HFEFH',
        'HH HH'
    ], {
        A: 'betterend:blue_vine_fur',
        B: 'betterend:filalux',
        C: 'betterend:lumecorn_rod',
        D: 'betterend:purple_polypore',
        E: 'betterend:mossy_glowshroom_fur',
        F: 'betterend:aurora_crystal',
        G: 'betterend:neon_cactus',
        H: 'betterend:emerald_ice'
    })


// Create Sequenced Assembly
    event.recipes.createSequencedAssembly([
        Item.of('1x createaddition:electric_motor'),
        ], 'createaddition:spool', [
            event.recipes.createDeploying('kubejs:incomplete_motor', ['kubejs:incomplete_motor', 'createaddition:copper_wire']),
            event.recipes.createDeploying('kubejs:incomplete_motor', ['kubejs:incomplete_motor', 'create:shaft']),
            event.recipes.createPressing('kubejs:incomplete_motor', 'kubejs:incomplete_motor').processingTime(100),
            event.recipes.createDeploying('kubejs:incomplete_motor', ['kubejs:incomplete_motor', 'create:brass_sheet']),
            event.recipes.createDeploying('kubejs:incomplete_motor', ['kubejs:incomplete_motor', 'createdeco:cast_iron_sheet']),
            event.recipes.createDeploying('kubejs:incomplete_motor', ['kubejs:incomplete_motor', 'create:electron_tube']),
        ]).transitionalItem('kubejs:incomplete_motor').loops(1)

    event.recipes.createSequencedAssembly([
        Item.of('1x createaddition:alternator'),
        ], 'createaddition:spool', [
            event.recipes.createDeploying('kubejs:incomplete_alternator', ['kubejs:incomplete_alternator', 'createaddition:gold_wire']),
            event.recipes.createDeploying('kubejs:incomplete_alternator', ['kubejs:incomplete_alternator', 'create:shaft']),
            event.recipes.createPressing('kubejs:incomplete_alternator', 'kubejs:incomplete_alternator').processingTime(100),
            event.recipes.createDeploying('kubejs:incomplete_alternator', ['kubejs:incomplete_alternator', 'create:brass_sheet']),
            event.recipes.createDeploying('kubejs:incomplete_alternator', ['kubejs:incomplete_alternator', 'createdeco:cast_iron_sheet']),
            event.recipes.createDeploying('kubejs:incomplete_alternator', ['kubejs:incomplete_alternator', 'createaddition:capacitor']),
        ]).transitionalItem('kubejs:incomplete_alternator').loops(1)


// Food
    event.recipes.createMixing('kubejs:rice_milk', ['#c:crops/rice','#c:crops/rice','#c:crops/rice','#c:crops/rice'])
    event.recipes.createCompacting(['kubejs:cheese', 'minecraft:glass_bottle'], 'farmersdelight:milk_bottle').heated()
    event.recipes.createCompacting('kubejs:cheese', 'kubejs:rice_milk').heated()

    event.recipes.createSequencedAssembly([
        Item.of('1x farmersdelight:hamburger'),
        ], '#c:bread', [
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:cooked_beef']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', 'kubejs:cheese']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/cabbage']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/tomato']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', 'farmersdelight:onion']),
        ]).transitionalItem('kubejs:incomplete_burger').loops(1)
      
    event.recipes.createSequencedAssembly([
        Item.of('1x kubejs:algae_burger'),
        ], '#c:bread', [
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', 'kubejs:plant_patty']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', 'minecraft:kelp']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/cabbage']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/tomato']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', 'farmersdelight:onion']),
        ]).transitionalItem('kubejs:incomplete_burger').loops(1)   

    event.recipes.createSequencedAssembly([
        Item.of('1x kubejs:plant_patty'),
        ], 'farmersdelight:rice', [
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/tomato']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:crops/onion']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:mushrooms']),
            event.recipes.createDeploying('kubejs:incomplete_burger', ['kubejs:incomplete_burger', '#c:flour/wheat']),
            event.recipes.createPressing('kubejs:incomplete_burger', 'kubejs:incomplete_burger').processingTime(100),
        ]).transitionalItem('kubejs:incomplete_burger').loops(1)
        
        
    event.recipes.createSequencedAssembly([
        Item.of('1x kubejs:pizza'),
        ], 'farmersdelight:wheat_dough', [
            event.recipes.createPressing('kubejs:incomplete_burger', 'kubejs:incomplete_burger').processingTime(100),
            event.recipes.createDeploying('kubejs:incomplete_pizza', ['kubejs:incomplete_pizza', 'farmersdelight:tomato_sauce']),
            event.recipes.createDeploying('kubejs:incomplete_pizza', ['kubejs:incomplete_pizza', '#c:cooked_beef']),
            event.recipes.createDeploying('kubejs:incomplete_pizza', ['kubejs:incomplete_pizza', 'kubejs:cheese']),
            event.recipes.createDeploying('kubejs:incomplete_pizza', ['kubejs:incomplete_pizza', '#c:crops/onion']),
            event.recipes.createDeploying('kubejs:incomplete_pizza', ['kubejs:incomplete_pizza', '#c:mushrooms']),
        ]).transitionalItem('kubejs:incomplete_pizza').loops(1)  
  })