//Create Live 4 Custom Items
//Author: RGB Pixl

StartupEvents.registry('item', event => {

    event.create('copper_gearcoin').displayName('Gearcoin (Copper)')
    event.create('golden_gearcoin').displayName('Gearcoin §6(Gold)')
    event.create('diamond_gearcoin').displayName('Gearcoin §b(Diamond)')
    event.create('netherite_gearcoin').displayName('Gearcoin §c(Netherite)')
    event.create('netherite_gearcoin_prestige').texture('kubejs:item/netherite_gearcoin').displayName('Gearcoin §d(Prestige)').glow(true).maxStackSize(16).tooltip('§eICH BIN REICH!')

    event.create('incomplete_motor', 'create:sequenced_assembly').displayName('Incomplete Electric Motor')
    event.create('incomplete_alternator', 'create:sequenced_assembly').displayName('Incomplete Alternator')
    event.create('incomplete_burger', 'create:sequenced_assembly').displayName('Incomplete Burger').texture('kubejs:item/plant_patty')
    event.create('incomplete_pizza', 'create:sequenced_assembly').displayName('Incomplete Pizza').texture('kubejs:item/pizza')


  //Food
	event.create('pizza').food(food => {
		food
    		.hunger(12)
    		.saturation(1)
      		.removeEffect('poison')
    })

    event.create('cheese').food(food => {
        food
            .hunger(2)
            .saturation(2)
            .removeEffect('poison')
    })

    event.create('plant_patty').food(food => {
		food
    		.hunger(4)
    		.saturation(1)  
    }).displayName('Plant-Based Patty')

    event.create('algae_burger').food(food => {
		food
    		.hunger(12)
    		.saturation(1)
    }).displayName('Algae Burger')

    event.create('rice_milk').food(food => {
		food
    		.hunger(3)
    		.saturation(1)
            .alwaysEdible()
            .removeEffect('poison')
    }).displayName('Rice Milk')
    
})