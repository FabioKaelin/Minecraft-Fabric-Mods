//Create Live 4 Custom Tags
//Author: RGB Pixl

//Add Tags

ServerEvents.tags('item', event => {
    event.add('c:cooked_beef', 'kubejs:plant_patty')
  })